﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrenadeHealth : MonoBehaviour
{
    //public
    public int bulletDamage; //dano da bala
    public int explosionDamage; //dano da explosao

    public string source; //fonte da bala --> se enemy dar dano em player vice-versa

    public float destroyDelay; //delay pra destruicao da bala depois de colidir

    public bool isFreezingBullet; //eh uma bala que congela? 
    public bool isBurningBullet; //eh uma bala que queima?

    //private
    private string target; //quem vai levar dano dessa bala?
    // private string layer; //layer do source
    private int collisionMask; //mascara para saber com quem a bala colide

    private bool bulletDestroying; //verifica se ja nao esta destruindo a bala/granada

    // Use this for initialization
    void Start()
    {
        if (source.Equals("Enemy"))
        {
            target = "Character"; //caso inimigo --> target player
            collisionMask = 1 << LayerMask.NameToLayer("PlayerBullet") | 1 << LayerMask.NameToLayer("EnemyBullet") | 1 << LayerMask.NameToLayer("Enemy"); //pegar layer corrente (bit shift + bit or)
        }
        else if (source.Equals("Character"))
        {
            target = "Enemy"; //caso player --> target inimigo
            //layer = "Character";
            collisionMask = 1 << LayerMask.NameToLayer("PlayerBullet") | 1 << LayerMask.NameToLayer("EnemyBullet") | 1 << LayerMask.NameToLayer("Character"); //pegar layer corrente (bit shift + bit or)
        }

        collisionMask = ~collisionMask; //todas menos as selecionadas (inverter)

        //bulletDestroying = true;
        bulletDestroying = false;
    }

    // Update is called once per frame
    void Update()
    {

    }

    //quando entrar no trigger
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer(target))
        {
            DoDamage(other);
        }

        //Debug.Log(other.gameObject.name);
        if ((collisionMask & (1 << other.gameObject.layer)) != 0) //se estiver colidindo com uma das layers selecionadas
        {
            //Debug.Log(other.gameObject.name);
            StartCoroutine(BulletDestroy()); //destroi bala
        }
    }

    public void DoDamage(Collider2D other) //dar dano no target (caso possivel)
    {
        other.gameObject.SendMessageUpwards("ReceiveDamage", bulletDamage, SendMessageOptions.DontRequireReceiver); //enviar dano, nao requisitar erro caso nao encontre

        //EnemyStatus enemyS = other.gameObject.GetComponent<EnemyStatus>(); //tentar pegar o script de status do alvo
        //if (enemyS != null) //se conseguir
        //{
        if (isFreezingBullet) //se for bala congelante
        {
            //enemyS.Freeze(-1f); //congelar pelo tempo padrao
            other.gameObject.SendMessageUpwards("Freeze", -1f, SendMessageOptions.DontRequireReceiver); //enviar freeze, nao requisitar erro caso nao encontre
        }
        if (isBurningBullet) //se for bala que queima
        {
            //enemyS.Burn(-1f); //queimar pelo tempo padrao
            other.gameObject.SendMessageUpwards("Burn", -1f, SendMessageOptions.DontRequireReceiver); //enviar burn, nao requisitar erro caso nao encontre
        }
        //}
    }

    public void DoDamage(GameObject other) //dar dano no target (caso possivel)
    {
        other.gameObject.SendMessageUpwards("ReceiveDamage", explosionDamage, SendMessageOptions.DontRequireReceiver); //enviar dano, nao requisitar erro caso nao encontre

        //EnemyStatus enemyS = other.gameObject.GetComponent<EnemyStatus>(); //tentar pegar o script de status do alvo
        //if (enemyS != null) //se conseguir
        //{
        if (isFreezingBullet) //se for bala congelante
        {
            //enemyS.Freeze(-1f); //congelar pelo tempo padrao
            other.gameObject.SendMessageUpwards("Freeze", -1f, SendMessageOptions.DontRequireReceiver); //enviar freeze, nao requisitar erro caso nao encontre
        }
        if (isBurningBullet) //se for bala que queima
        {
            //enemyS.Burn(-1f); //queimar pelo tempo padrao
            other.gameObject.SendMessageUpwards("Burn", -1f, SendMessageOptions.DontRequireReceiver); //enviar burn, nao requisitar erro caso nao encontre
        }
        //}
    }

    public void DestroyByTime(float lifeTime)
    {
        StartCoroutine(WaitDestruction(lifeTime));
    }

    public IEnumerator WaitDestruction(float lifeTime)
    {
        //Debug.Log("Waiting for time");
        yield return new WaitForSeconds(lifeTime);
        //Debug.Log("Starting destruction");
        //BulletDestroy();
        StartCoroutine(BulletDestroy()); //destroi bala
    }

    public IEnumerator BulletDestroy() //destroi a bala
    {
        if (!bulletDestroying)
        {
            bulletDestroying = true;

            GrenadeController grenadeC = gameObject.GetComponent<GrenadeController>();
            float limitTime = grenadeC.Explode(collisionMask); // tempo para explodir

            yield return new WaitForSeconds(destroyDelay); //esperar x segundos antes de destruir bala

            HashSet<GameObject> listOfDamages = grenadeC.GetListOfDamages();
            foreach (GameObject gameO in listOfDamages) ////pra cada objeto verificar se eh um target e dar dano
            {
                if (gameO.gameObject.layer == LayerMask.NameToLayer(target))
                {
                    GameObject gmO = DoLaser((gameO.transform.position - gameObject.transform.position), grenadeC.explosionRadius); //tentar acertar o alvo pela range
                    if (gmO == null || gmO == gameO)
                    { //se foi possivel alcancar o alvo (sem barreiras)
                        DoDamage(gameO); //dar dano
                    }
                }
            }

            Destroy(gameObject, limitTime); //destroi bala quando colide //implementar bala perfuravel--> tirar destroy/arrumar //tempo pra destruir objeto
        }
    }

    public GameObject DoLaser(Vector3 direction, float maxRange) //faz um raycast na direcao da arma pra ver se acerta algo (/o player) [caso acerte o target, retorna true, caos nao, false]
    {
        //Transform bulletSpawnTransform = bulletSpawn.transform; //pegar transform
        //Vector3 pontoFinalLaser = bulletSpawnTransform.position + bulletSpawnTransform.right * maxRange; //pra frente vermelho ate distancia maxima

        RaycastHit2D pontoColisao; //ponto de colisao do laser antes da distancia maxima

        Ray2D ray = new Ray2D(gameObject.transform.position, direction); //criar raio da posicao na direcao da seta vermelha (do mundo) 

        pontoColisao = Physics2D.Raycast(ray.origin, direction, maxRange, collisionMask);//, LayerMask.NameToLayer("PlayerBullet")); //com ponto de colisao e distancia e ignorar layers de inimgos, balas e do character

/*<----------->*/        Debug.DrawLine(ray.origin, pontoColisao.point, new Color(10, 10, 10), 100f);

        //Debug.Log(pontoColisao.collider + " bla " + LayerMask.NameToLayer("PlayerBullet"));
        if (pontoColisao.collider) //verificar hit com algo
        {
            //lightCollider.transform.position = pontoColisao.point;// - (Vector2)posLuz; //alterar fim do laser

            return pontoColisao.transform.gameObject;
            //if (pontoColisao.transform.gameObject == target) return true;

            //Debug.Log(pontoColisao.transform.gameObject.name);
            //Debug.Log(startPos + "  " + scale.magnitude);
        }

        return null; //nao acertou o player
    }
}
